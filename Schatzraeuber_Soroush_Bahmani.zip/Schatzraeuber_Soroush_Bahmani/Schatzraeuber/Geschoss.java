import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Ein Geschoss wird vom Wächter abgefeuert. Berührt es den Abenteurer,
 * wird der Abenteurer aus der Welt entfernt.
 *
 * Hinweis: Geschoss erbt von Person, bewegt sich in dieser Version aber
 * nicht selbstständig - es entsteht direkt an der Position des Wächters
 * und wirkt nur über die Berührung mit dem Abenteurer.
 *
 * @author Soroush Bahmani
 */
public class Geschoss extends Person
{
    /**
     * Wird bei jedem Simulationsschritt aufgerufen und prüft, ob das
     * Geschoss den Abenteurer trifft.
     */
    public void act()
    {
        pruefeAbenteurer();
    }

    /**
     * Prüft, ob das Geschoss gerade den Abenteurer berührt, und entfernt
     * ihn in diesem Fall aus der Welt.
     */
    private void pruefeAbenteurer()
    {
        if (this.isTouching(Abenteurer.class))
        {
            new GreenfootSound("treffer.mp3").play();
            removeTouching(Abenteurer.class);
        }
    }
}
