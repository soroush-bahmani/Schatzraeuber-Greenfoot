import greenfoot.*;

/**
 * Diese Klasse modelliert eine Wand. Wände blockieren die Bewegung von
 * Personen (siehe Person.move()) und dienen als Hindernisse in der
 * Schatzkammer.
 *
 * @author Soroush Bahmani
 */
public class Wand extends Actor
{
    // Eine Wand führt keine eigene Aktion aus - sie wirkt nur passiv
    // als Hindernis, gegen das andere Objekte ihre Position prüfen.
}
