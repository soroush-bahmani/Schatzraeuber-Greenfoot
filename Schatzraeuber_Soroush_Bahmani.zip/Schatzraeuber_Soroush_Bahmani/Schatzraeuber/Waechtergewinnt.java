import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Anzeige-Objekt, das eingeblendet wird, wenn der Wächter das Spiel
 * gewonnen hat (siehe Schatzkammer.gewinnspiel()).
 *
 * @author Soroush Bahmani
 */
public class Waechtergewinnt extends Actor
{
    /**
     * Erzeugt die Gewinn-Anzeige und spielt sofort den Sieg-Sound ab.
     */
    public Waechtergewinnt()
    {
        new GreenfootSound("sieg.mp3").play();
    }

    /**
     * Dient nur zur Anzeige - es ist keine eigene Aktion nötig.
     */
    public void act()
    {
    }
}
