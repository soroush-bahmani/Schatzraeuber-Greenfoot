import greenfoot.*;
import java.util.List;
import java.lang.Class;

/**
 * Die Klasse MyWorld ist eine Unterklasse von World, die zusätzlich die
 * Möglichkeit bietet, die Anzahl der Objekte einer bestimmten Klasse zu
 * zählen, die sich auf der Welt (bzw. in einer einzelnen Zelle) befinden.
 * Schatzkammer erbt von dieser Klasse.
 *
 * @author Soroush Bahmani
 */
public abstract class MyWorld extends World
{
    /**
     * Konstruktor für Objekte der Klasse MyWorld.
     *
     * @param worldWidth  die Breite der Welt in Zellen
     * @param worldHeight die Höhe der Welt in Zellen
     * @param cellSize    die Breite und Höhe einer Zelle in Pixeln
     */
    public MyWorld(int worldWidth, int worldHeight, int cellSize)
    {
        super(worldWidth, worldHeight, cellSize);
    }

    /**
     * Zählt die Objekte einer Klasse in der gesamten Welt.
     *
     * @param cls die Klasse, deren Objekte gezählt werden sollen
     * @return die Anzahl der entsprechenden Objekte
     */
    public int count(Class cls)
    {
        List list = getObjects(cls);
        return list.size();
    }

    /**
     * Zählt die Objekte einer Klasse in einer einzelnen Zelle der Welt.
     *
     * @param x   die x-Koordinate der Zelle
     * @param y   die y-Koordinate der Zelle
     * @param cls die Klasse, deren Objekte gezählt werden sollen
     * @return die Anzahl der entsprechenden Objekte
     */
    public int count(int x, int y, Class cls)
    {
        List list = getObjectsAt(x, y, cls);
        return list.size();
    }
}
