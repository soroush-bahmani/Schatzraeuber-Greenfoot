import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Der Gehilfe unterstützt den Abenteurer: Er bewegt sich zufällig durch
 * die Schatzkammer und schaltet den Wächter aus, sobald er ihn berührt.
 *
 * @author Soroush Bahmani
 */
public class Gehilfe extends Person
{
    /**
     * Wird bei jedem Simulationsschritt aufgerufen: zufällige Bewegung und
     * anschließende Prüfung, ob der Wächter berührt wird.
     */
    public void act()
    {
        pruefeWaechter();
        bewegen();
    }

    /**
     * Bewegt den Gehilfen zufällig in eine der vier Richtungen
     * (rechts, links, oben, unten).
     */
    private void bewegen()
    {
        int zahl = Greenfoot.getRandomNumber(4);
        if (zahl == 1)
        {
            move('r');
        }
        if (zahl == 2)
        {
            move('l');
        }
        if (zahl == 3)
        {
            move('o');
        }
        if (zahl == 4)
        {
            move('u');
        }
    }

    /**
     * Prüft, ob der Gehilfe gerade den Wächter berührt, und entfernt
     * ihn in diesem Fall aus der Welt.
     */
    private void pruefeWaechter()
    {
        if (this.isTouching(Waechter.class))
        {
            new GreenfootSound("treffer.mp3").play();
            removeTouching(Waechter.class);
        }
    }
}
