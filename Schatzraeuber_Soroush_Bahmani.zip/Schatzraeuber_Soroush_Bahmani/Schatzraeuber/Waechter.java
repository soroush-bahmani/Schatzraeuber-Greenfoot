import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Der Wächter ist die vom zweiten Spieler gesteuerte Spielfigur.
 * Er bewegt sich mit W/A/S/D durch die Schatzkammer, kann mit der
 * Shift-Taste Geschosse auf den Abenteurer abfeuern und gewinnt, sobald
 * er den Abenteurer selbst berührt oder alle Wächter-Verbündeten
 * (Gehilfen des Gegners) ausgeschaltet sind.
 *
 * @author Soroush Bahmani
 */
public class Waechter extends Person
{
    /** Maximale Anzahl an Geschossen, die gleichzeitig in der Welt sein dürfen. */
    private static final int MAX_GESCHOSSE = 2;

    /**
     * Wird bei jedem Simulationsschritt aufgerufen: Bewegung, Kollisions-
     * prüfung mit dem Abenteurer und das Abfeuern von Geschossen.
     */
    public void act()
    {
        bewegen();
        pruefeAbenteurer();
        geschoss();
    }

    /**
     * Bewegt den Wächter je nach gedrückter Taste (W/A/S/D) um ein Feld.
     */
    private void bewegen()
    {
        if (Greenfoot.isKeyDown("a"))
        {
            move('l');
        }
        if (Greenfoot.isKeyDown("d"))
        {
            move('r');
        }
        if (Greenfoot.isKeyDown("w"))
        {
            move('o');
        }
        if (Greenfoot.isKeyDown("s"))
        {
            move('u');
        }
    }

    /**
     * Prüft, ob der Wächter gerade den Abenteurer berührt, und entfernt
     * ihn in diesem Fall aus der Welt (Wächter hat gewonnen).
     */
    private void pruefeAbenteurer()
    {
        if (this.isTouching(Abenteurer.class))
        {
            new GreenfootSound("treffer.mp3").play();
            removeTouching(Abenteurer.class);
        }
    }

    /**
     * Erzeugt beim Drücken von Shift ein neues Geschoss an der aktuellen
     * Position des Wächters, solange die maximale Anzahl gleichzeitiger
     * Geschosse noch nicht erreicht ist.
     */
    private void geschoss()
    {
        if (Greenfoot.isKeyDown("shift")
                && getWorldOfType(MyWorld.class).count(Geschoss.class) < MAX_GESCHOSSE)
        {
            new GreenfootSound("schuss.mp3").play();
            Geschoss meinGeschoss = new Geschoss();
            this.getWorld().addObject(meinGeschoss, this.getX(), this.getY());
        }
    }
}
