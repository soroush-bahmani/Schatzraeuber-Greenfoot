import greenfoot.*;

/**
 * Die Schatzkammer ist die Spielwelt von "Schatzräuber". Hier treten
 * Abenteurer und Wächter gegeneinander an: Der Abenteurer versucht,
 * genügend Schätze einzusammeln, während der Wächter versucht, ihn
 * aufzuhalten. Zusätzlich wechselt die Kammer zwischen Tag und Nacht.
 *
 * @author Soroush Bahmani
 */
public class Schatzkammer extends MyWorld
{
    // Anzahl Wände / Schätze, die zu Beginn platziert werden
    private static final int ANZAHL_WAENDE = 70;
    private static final int ANZAHL_SCHAETZE = 45;

    // Sobald weniger als diese Anzahl Schätze übrig ist, hat der Abenteurer gewonnen
    private static final int SCHAETZE_ZUM_SIEG = 3;

    // Tag/Nachtzyklus: Dauer einer Phase in Simulationsschritten
    private final int tagDauer = 100;
    private final int nachtDauer = 100;
    private int tickCounter = 0;
    private boolean istTag = true;

    // Punktesystem: Punkte, die pro eingesammeltem Schatz vergeben werden
    private static final int PUNKTE_PRO_SCHATZ = 10;
    private int punkte = 0;

    /**
     * Erzeugt eine neue Schatzkammer, platziert die Startobjekte und
     * setzt den anfänglichen Hintergrund sowie die Punkteanzeige.
     */
    public Schatzkammer()
    {
        super(20, 20, 30);
        prepare();
        tagesspiel();
        zeigePunkte();
    }

    /**
     * Wird bei jedem Simulationsschritt aufgerufen: prüft die Siegbedingungen
     * und steuert den Tag-/Nachtwechsel.
     */
    public void act()
    {
        gewinnspiel();
        tickCounter++;

        if (istTag && tickCounter >= tagDauer)
        {
            setBackground(new GreenfootImage("warum-funkeln-sterne-glitzern-blinken.jpg"));
            new GreenfootSound("nacht.mp3").play();
            istTag = false;
            tickCounter = 0;
        }
        else if (!istTag && tickCounter >= nachtDauer)
        {
            setBackground(new GreenfootImage("internationaler-tag-der-sauberen-luft-für-einen-blauen-himmel.jpg"));
            new GreenfootSound("kikeriki.mp3").play();
            istTag = true;
            tickCounter = 0;
        }
    }

    /**
     * Bereitet die Welt für den Spielstart vor: platziert Wände, Schätze,
     * den Abenteurer, den Wächter und den Gehilfen.
     */
    private void prepare()
    {
        // Wände zufällig verteilen
        for (int i = 0; i < ANZAHL_WAENDE; i++)
        {
            int x = Greenfoot.getRandomNumber(19);
            int y = Greenfoot.getRandomNumber(17) + 1;
            Wand wand = new Wand();
            addObject(wand, x, y);
        }

        // Schätze zufällig verteilen, aber nicht auf Feldern mit einer Wand
        for (int i = 0; i < ANZAHL_SCHAETZE; i++)
        {
            int x = Greenfoot.getRandomNumber(19);
            int y = Greenfoot.getRandomNumber(17) + 1;
            if (count(x, y, Wand.class) == 0)
            {
                Schatz schatz = new Schatz();
                addObject(schatz, x, y);
            }
            else
            {
                // Feld war durch eine Wand belegt: Versuch wiederholen
                i--;
            }
        }

        // Abenteurer unten, Wächter oben in der Welt platzieren
        int startspaltAbenteurer = Greenfoot.getRandomNumber(19);
        Abenteurer a = new Abenteurer();
        addObject(a, startspaltAbenteurer, 19);

        int startspaltWaechter = Greenfoot.getRandomNumber(19);
        Waechter waechter = new Waechter();
        addObject(waechter, startspaltWaechter, 0);

        // Gehilfe startet in der gleichen Spalte wie der Abenteurer
        Gehilfe gehilfe = new Gehilfe();
        addObject(gehilfe, startspaltAbenteurer, 8);
    }

    /**
     * Prüft nach jedem Simulationsschritt, ob eine der Siegbedingungen
     * erfüllt ist, und beendet in diesem Fall das Spiel:
     *   Abenteurer gewinnt, wenn nur noch weniger als SCHAETZE_ZUM_SIEG
     *   Schätze übrig sind, oder wenn der Wächter ausgeschaltet wurde.
     *   Wächter gewinnt, wenn der Abenteurer ausgeschaltet wurde.
     */
    private void gewinnspiel()
    {
        if (count(Schatz.class) < SCHAETZE_ZUM_SIEG)
        {
            Abenteurergewinnt a = new Abenteurergewinnt();
            addObject(a, 9, 9);
            Greenfoot.stop();
        }

        if (count(Abenteurer.class) == 0)
        {
            Waechtergewinnt w = new Waechtergewinnt();
            addObject(w, 9, 9);
            Greenfoot.stop();
        }

        if (count(Waechter.class) <= 0)
        {
            Abenteurergewinnt a = new Abenteurergewinnt();
            addObject(a, 9, 9);
            Greenfoot.stop();
        }
    }

    /**
     * Setzt den anfänglichen Hintergrund der Schatzkammer.
     *
     * Hinweis: Das erste setBackground() wird sofort durch das zweite
     * überschrieben. Falls hier bewusst mit einem Taghintergrund gestartet
     * werden soll, kann die erste Zeile entfernt werden.
     */
    private void tagesspiel()
    {
        setBackground(new GreenfootImage("warum-funkeln-sterne-glitzern-blinken.jpg"));
        setBackground(new GreenfootImage("internationaler-tag-der-sauberen-luft-für-einen-blauen-himmel.jpg"));
    }

    /**
     * Erhöht die Punktzahl um die Punkte für einen eingesammelten Schatz
     * und aktualisiert die Anzeige. Wird vom Abenteurer aufgerufen, sobald
     * er einen Schatz einsammelt.
     */
    public void addPunkte()
    {
        punkte += PUNKTE_PRO_SCHATZ;
        zeigePunkte();
    }

    /**
     * Zeigt die aktuelle Punktzahl in der Welt an.
     */
    private void zeigePunkte()
    {
        showText("Punkte: " + punkte, 2, 0);
    }
}
