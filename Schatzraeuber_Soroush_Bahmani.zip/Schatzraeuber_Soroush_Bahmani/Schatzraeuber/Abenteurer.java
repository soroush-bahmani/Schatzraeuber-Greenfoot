import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Der Abenteurer ist die vom ersten Spieler gesteuerte Spielfigur.
 * Er bewegt sich mit den Pfeiltasten durch die Schatzkammer und sammelt
 * Schätze ein. Ziel des Abenteurers ist es, genügend Schätze einzusammeln,
 * bevor der Wächter ihn erwischt.
 *
 * @author Soroush Bahmani
 */
public class Abenteurer extends Person
{
    /**
     * Wird bei jedem Simulationsschritt aufgerufen: Der Abenteurer bewegt
     * sich entsprechend der Tastatureingabe und prüft anschließend, ob er
     * gerade einen Schatz berührt.
     */
    public void act()
    {
        bewegen();
        pruefeSchatz();
    }

    /**
     * Bewegt den Abenteurer je nach gedrückter Pfeiltaste um ein Feld.
     * Rechts/Links/Oben/Unten sind über die Konstanten 'r', 'l', 'o', 'u'
     * der geerbten move()-Methode aus Person realisiert.
     */
    private void bewegen()
    {
        if (Greenfoot.isKeyDown("right"))
        {
            move('r');
        }
        if (Greenfoot.isKeyDown("left"))
        {
            move('l');
        }
        if (Greenfoot.isKeyDown("up"))
        {
            move('o');
        }
        if (Greenfoot.isKeyDown("down"))
        {
            move('u');
        }
    }

    /**
     * Prüft, ob der Abenteurer gerade einen Schatz berührt, und sammelt
     * ihn in diesem Fall ein: Sound abspielen, Schatz aus der Welt
     * entfernen und die Punktzahl in der Schatzkammer erhöhen.
     */
    private void pruefeSchatz()
    {
        if (this.isTouching(Schatz.class))
        {
            new GreenfootSound("muenze.mp3").play();
            removeTouching(Schatz.class);

            Schatzkammer welt = getWorldOfType(Schatzkammer.class);
            if (welt != null)
            {
                welt.addPunkte();
            }
        }
    }
}
