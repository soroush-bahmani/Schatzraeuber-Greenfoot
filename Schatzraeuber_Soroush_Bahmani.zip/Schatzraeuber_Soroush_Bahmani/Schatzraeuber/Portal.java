import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Das Portal soll perspektivisch als weiteres Spielelement dienen (z. B.
 * als zufälliger Ein-/Ausgang in der Schatzkammer).
 *
 * Hinweis: Aktuell wird in Schatzkammer.prepare() noch kein Portal-Objekt
 * erzeugt - die Klasse ist also vorbereitet, aber noch nicht ins Spiel
 * eingebunden.
 *
 * @author Soroush Bahmani
 */
public class Portal extends Person
{
    /**
     * Erzeugt ein neues Portal mit dem passenden Bild.
     */
    public Portal()
    {
        setImage("house-03.png");
    }

    /**
     * Das Portal führt aktuell keine eigene Aktion aus.
     */
    public void act()
    {
    }

    /**
     * Erzeugt eine zufällige Position innerhalb der übergebenen Welt.
     *
     * @param welt die Welt, in der die Position bestimmt werden soll
     * @return ein Array [x, y] mit der zufälligen Position
     */
    public int[] generiereZufallsPosition(World welt)
    {
        int x = Greenfoot.getRandomNumber(welt.getWidth());
        int y = Greenfoot.getRandomNumber(welt.getHeight());
        return new int[] {x, y};
    }
}
