import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Ein Schatz liegt passiv in der Schatzkammer und wird vom Abenteurer
 * eingesammelt, sobald dieser ihn berührt (siehe Abenteurer.checkSchatz()).
 *
 * @author Soroush Bahmani
 */
public class Schatz extends Actor
{
    /**
     * Der Schatz führt selbst keine Aktion aus - er wartet passiv darauf,
     * vom Abenteurer eingesammelt zu werden.
     */
    public void act()
    {
    }
}
