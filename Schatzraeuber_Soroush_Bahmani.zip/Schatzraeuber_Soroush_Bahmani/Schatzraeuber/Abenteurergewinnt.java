import greenfoot.*;  // World, Actor, GreenfootImage, Greenfoot, MouseInfo

/**
 * Anzeige-Objekt, das eingeblendet wird, wenn der Abenteurer das Spiel
 * gewonnen hat (siehe Schatzkammer.gewinnspiel()).
 *
 * @author Soroush Bahmani
 */
public class Abenteurergewinnt extends Actor
{
    /**
     * Erzeugt die Gewinn-Anzeige und spielt sofort den Sieg-Sound ab.
     */
    public Abenteurergewinnt()
    {
        new GreenfootSound("sieg.mp3").play();
    }

    /**
     * Dient nur zur Anzeige - es ist keine eigene Aktion nötig.
     */
    public void act()
    {
    }
}
